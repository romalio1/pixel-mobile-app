const STORAGE_KEY = "pixelApplicationsSystem";

const initialData = {
    customers: [
        { id: 1, name: "Иванов Иван", phone: "+7 900 123-45-67" },
        { id: 2, name: "Петрова Анна", phone: "+7 900 555-12-34" },
        { id: 3, name: "Сидоров Максим", phone: "+7 900 777-88-99" }
    ],
    products: [
        { id: 1, name: "iPhone 15", price: 79990 },
        { id: 2, name: "Ноутбук ASUS", price: 65990 },
        { id: 3, name: "Наушники Sony", price: 15990 },
        { id: 4, name: "Монитор Samsung", price: 24990 }
    ],
    employees: [
        { id: 1, name: "Смирнов Алексей", position: "Менеджер" },
        { id: 2, name: "Кузнецова Мария", position: "Продавец-консультант" },
        { id: 3, name: "Орлов Дмитрий", position: "Менеджер" }
    ],
    applications: [
        {
            id: 1, customerId: 1, productId: 1,
            employeeId: 1, quantity: 1,
            date: "08.10.2026", status: "Новая"
        },
        {
            id: 2, customerId: 2, productId: 2,
            employeeId: 2, quantity: 1,
            date: "08.10.2026", status: "В обработке"
        },
        {
            id: 3, customerId: 3, productId: 3,
            employeeId: 3, quantity: 2,
            date: "07.10.2026", status: "Выполнена"
        }
    ]
};

let customers = [];
let products = [];
let employees = [];
let applications = [];

const statuses = ["Новая", "В обработке", "Выполнена"];

function escapeHTML(value) {
    return String(value)
        .replace(/&/g, "&amp;")
        .replace(/</g, "&lt;")
        .replace(/>/g, "&gt;")
        .replace(/"/g, "&quot;")
        .replace(/'/g, "&#39;");
}

function formatPrice(price) {
    return Number(price).toLocaleString("ru-RU", {
        maximumFractionDigits: 2
    }) + " ₽";
}

function nextId(items) {
    return items.length
        ? Math.max(...items.map(item => item.id)) + 1
        : 1;
}

function saveData() {
    try {
        localStorage.setItem(STORAGE_KEY, JSON.stringify({
            customers,
            products,
            employees,
            applications
        }));
    } catch (error) {
        console.error("Ошибка сохранения данных:", error);
        alert("Не удалось сохранить данные. Проверьте настройки браузера.");
    }
}

function loadData() {
    try {
        const saved = localStorage.getItem(STORAGE_KEY);

        if (!saved) {
            customers = initialData.customers.map(item => ({ ...item }));
            products = initialData.products.map(item => ({ ...item }));
            employees = initialData.employees.map(item => ({ ...item }));
            applications = initialData.applications.map(item => ({ ...item }));
            saveData();
            return;
        }

        const data = JSON.parse(saved);

        if (
            !Array.isArray(data.customers) ||
            !Array.isArray(data.products) ||
            !Array.isArray(data.employees) ||
            !Array.isArray(data.applications)
        ) {
            throw new Error("Неверный формат сохранённых данных");
        }

        customers = data.customers;
        products = data.products;
        employees = data.employees;
        applications = data.applications;
    } catch (error) {
        console.error("Ошибка загрузки данных:", error);
        alert("Не удалось прочитать сохранённые данные. Загружены начальные данные.");

        customers = initialData.customers.map(item => ({ ...item }));
        products = initialData.products.map(item => ({ ...item }));
        employees = initialData.employees.map(item => ({ ...item }));
        applications = initialData.applications.map(item => ({ ...item }));

        saveData();
    }
}

function showPage(pageId, button) {
    document.querySelectorAll(".page").forEach(page => {
        page.classList.remove("active");
    });

    const page = document.getElementById(pageId);

    if (!page) return;

    page.classList.add("active");

    document.querySelectorAll("aside button").forEach(btn => {
        btn.classList.remove("active");
    });

    if (button) {
        button.classList.add("active");
    }

    refreshPage(pageId);
}

function openPage(pageId) {
    showPage(pageId, null);

    document.querySelectorAll("aside button").forEach(button => {
        const handler = button.getAttribute("onclick") || "";
        if (handler.includes("'" + pageId + "'")) {
            button.classList.add("active");
        }
    });
}

function goHome() {
    openPage("home");
}

function refreshPage(pageId) {
    if (pageId === "home") updateStatistics();
    if (pageId === "applications") renderApplications();
    if (pageId === "customers") renderCustomers();
    if (pageId === "products") renderProducts();
    if (pageId === "employees") renderEmployees();

    if (pageId === "add") {
        renderCustomerSelect();
        renderProductSelect();
        renderEmployeeSelect();
        updateApplicationPrice();
    }

    if (pageId === "search") searchApplications();
    if (pageId === "reports") renderReports();
    if (pageId === "details" && currentDetailsId !== null) {
        renderApplicationDetails(currentDetailsId);
    }
}

function showMessage(elementId, text, good = true) {
    const element = document.getElementById(elementId);

    if (!element) return;

    element.textContent = text;
    element.className = good ? "message show good" : "message show bad";
}

function clearMessage(elementId) {
    const element = document.getElementById(elementId);

    if (element) {
        element.textContent = "";
        element.className = "message";
    }
}

function getCurrentDate() {
    const date = new Date();

    return String(date.getDate()).padStart(2, "0") + "." +
        String(date.getMonth() + 1).padStart(2, "0") + "." +
        date.getFullYear();
}

function parseDate(dateString) {
    const parts = String(dateString).split(".");

    if (parts.length !== 3) return 0;

    const day = Number(parts[0]);
    const month = Number(parts[1]);
    const year = Number(parts[2]);

    const date = new Date(year, month - 1, day);

    if (
        date.getFullYear() !== year ||
        date.getMonth() !== month - 1 ||
        date.getDate() !== day
    ) {
        return 0;
    }

    return date.getTime();
}

function getCustomer(id) {
    return customers.find(item => item.id === Number(id));
}

function getProduct(id) {
    return products.find(item => item.id === Number(id));
}

function getEmployee(id) {
    return employees.find(item => item.id === Number(id));
}

function getApplicationPrice(application) {
    const product = getProduct(application.productId);

    return product ? product.price * application.quantity : 0;
}

function getStatusClass(status) {
    if (status === "Выполнена") return "success";
    if (status === "Новая") return "new";
    return "waiting";
}

/* ПОКУПАТЕЛИ */

function renderCustomerSelect() {
    const select = document.getElementById("customer");
    if (!select) return;

    select.innerHTML = '<option value="">Выберите покупателя</option>';

    customers.forEach(customer => {
        const option = document.createElement("option");
        option.value = customer.id;
        option.textContent = customer.name + " — " + customer.phone;
        select.appendChild(option);
    });
}

function normalizePhone(phone) {
    const digits = phone.replace(/\D/g, "");

    if (digits.length === 11 && digits.startsWith("8")) {
        return "7" + digits.substring(1);
    }

    if (digits.length === 10) {
        return "7" + digits;
    }

    return digits;
}

function isValidPhone(phone) {
    return /^7\d{10}$/.test(normalizePhone(phone));
}

function addCustomer() {
    const name = document.getElementById("newCustomerName").value.trim();
    const phone = document.getElementById("newCustomerPhone").value.trim();

    if (name.length < 2 || name.length > 100) {
        showMessage("customerMessage", "Введите ФИО длиной от 2 до 100 символов.", false);
        return;
    }

    if (/[<>]/.test(name)) {
        showMessage("customerMessage", "Недопустимые символы в ФИО.", false);
        return;
    }

    if (!isValidPhone(phone)) {
        showMessage("customerMessage", "Введите корректный российский номер телефона.", false);
        return;
    }

    const normalizedPhone = normalizePhone(phone);

    if (customers.some(item => normalizePhone(item.phone) === normalizedPhone)) {
        showMessage("customerMessage", "Покупатель с таким телефоном уже существует.", false);
        return;
    }

    const newCustomer = {
        id: nextId(customers),
        name,
        phone: formatPhone(normalizedPhone)
    };

    customers.push(newCustomer);

    saveData();
    renderCustomers();
    renderCustomerSelect();
    updateStatistics();

    document.getElementById("newCustomerName").value = "";
    document.getElementById("newCustomerPhone").value = "";

    document.getElementById("customer").value = String(newCustomer.id);

    showMessage("customerMessage", "Покупатель успешно добавлен.");
}

function formatPhone(phone) {
    const digits = normalizePhone(phone);

    if (!/^7\d{10}$/.test(digits)) return phone;

    return "+7 " + digits.substring(1, 4) + " " +
        digits.substring(4, 7) + "-" +
        digits.substring(7, 9) + "-" +
        digits.substring(9, 11);
}

function phoneMask(input) {
    let digits = input.value.replace(/\D/g, "");

    if (digits.startsWith("8") || digits.startsWith("7")) {
        digits = digits.substring(1);
    }

    digits = digits.substring(0, 10);

    let result = "+7";

    if (digits.length > 0) result += " " + digits.substring(0, 3);
    if (digits.length > 3) result += " " + digits.substring(3, 6);
    if (digits.length > 6) result += "-" + digits.substring(6, 8);
    if (digits.length > 8) result += "-" + digits.substring(8, 10);

    input.value = result;
}

function renderCustomers() {
    const table = document.getElementById("customersTable");
    table.innerHTML = "";

    customers.forEach((customer, index) => {
        const row = document.createElement("tr");

        row.innerHTML = `
            <td>${index + 1}</td>
            <td>${escapeHTML(customer.name)}</td>
            <td>${escapeHTML(customer.phone)}</td>
            <td>
                <button class="action-button edit"
                    onclick="editCustomer(${customer.id})">Изменить</button>
                <button class="action-button danger"
                    onclick="deleteCustomer(${customer.id})">Удалить</button>
            </td>
        `;

        table.appendChild(row);
    });

    document.getElementById("customersCount").textContent = customers.length;
}

function editCustomer(id) {
    const customer = getCustomer(id);
    if (!customer) return;

    const name = prompt("Введите новое ФИО:", customer.name);
    if (name === null) return;

    const phone = prompt("Введите новый телефон:", customer.phone);
    if (phone === null) return;

    const cleanName = name.trim();

    if (cleanName.length < 2 || cleanName.length > 100 || /[<>]/.test(cleanName)) {
        alert("ФИО должно содержать от 2 до 100 символов.");
        return;
    }

    if (!isValidPhone(phone)) {
        alert("Введите корректный российский номер телефона.");
        return;
    }

    const normalizedPhone = normalizePhone(phone);

    if (customers.some(item =>
        item.id !== customer.id &&
        normalizePhone(item.phone) === normalizedPhone
    )) {
        alert("Покупатель с таким телефоном уже существует.");
        return;
    }

    customer.name = cleanName;
    customer.phone = formatPhone(normalizedPhone);

    saveData();
    renderCustomers();
    renderCustomerSelect();
    renderApplications();
    searchApplications();
    renderReports();
    updateStatistics();

    showMessage("customerMessage", "Данные покупателя изменены.");
}

function deleteCustomer(id) {
    if (applications.some(item => item.customerId === id)) {
        alert("Нельзя удалить покупателя, у которого есть заявки.");
        return;
    }

    if (!confirm("Удалить покупателя?")) return;

    customers = customers.filter(item => item.id !== id);

    saveData();
    renderCustomers();
    renderCustomerSelect();
    updateStatistics();
}

/* ТОВАРЫ */

function renderProductSelect() {
    const select = document.getElementById("product");
    if (!select) return;

    select.innerHTML = '<option value="">Выберите товар</option>';

    products.forEach(product => {
        const option = document.createElement("option");
        option.value = product.id;
        option.textContent = product.name + " — " + formatPrice(product.price);
        select.appendChild(option);
    });
}

function addProduct() {
    const name = document.getElementById("newProductName").value.trim();
    const priceInput = document.getElementById("newProductPrice").value.trim();
    const price = Number(priceInput);

    if (name.length < 2 || name.length > 100 || /[<>]/.test(name)) {
        showMessage("productMessage", "Название товара должно содержать от 2 до 100 символов.", false);
        return;
    }

    if (
        priceInput === "" ||
        !Number.isFinite(price) ||
        price <= 0 ||
        price > 100000000
    ) {
        showMessage("productMessage", "Цена должна быть больше 0 и не превышать 100 000 000 ₽.", false);
        return;
    }

    if (products.some(item => item.name.toLowerCase() === name.toLowerCase())) {
        showMessage("productMessage", "Товар с таким названием уже существует.", false);
        return;
    }

    products.push({
        id: nextId(products),
        name,
        price: Math.round(price * 100) / 100
    });

    saveData();
    renderProducts();
    renderProductSelect();

    document.getElementById("newProductName").value = "";
    document.getElementById("newProductPrice").value = "";

    showMessage("productMessage", "Товар успешно добавлен.");
}

function renderProducts() {
    const table = document.getElementById("productsTable");
    table.innerHTML = "";

    products.forEach((product, index) => {
        const row = document.createElement("tr");

        row.innerHTML = `
            <td>${index + 1}</td>
            <td>${escapeHTML(product.name)}</td>
            <td>${formatPrice(product.price)}</td>
            <td>
                <button class="action-button edit"
                    onclick="editProduct(${product.id})">Изменить</button>
                <button class="action-button danger"
                    onclick="deleteProduct(${product.id})">Удалить</button>
            </td>
        `;

        table.appendChild(row);
    });
}

function editProduct(id) {
    const product = getProduct(id);
    if (!product) return;

    const name = prompt("Введите новое название товара:", product.name);
    if (name === null) return;

    const priceText = prompt("Введите новую цену:", product.price);
    if (priceText === null) return;

    const cleanName = name.trim();
    const price = Number(priceText);

    if (cleanName.length < 2 || cleanName.length > 100 || /[<>]/.test(cleanName)) {
        alert("Введите корректное название товара.");
        return;
    }

    if (!Number.isFinite(price) || price <= 0 || price > 100000000) {
        alert("Цена должна быть больше 0 и не превышать 100 000 000 ₽.");
        return;
    }

    if (products.some(item =>
        item.id !== product.id &&
        item.name.toLowerCase() === cleanName.toLowerCase()
    )) {
        alert("Товар с таким названием уже существует.");
        return;
    }

    product.name = cleanName;
    product.price = Math.round(price * 100) / 100;

    saveData();
    renderProducts();
    renderProductSelect();
    renderApplications();
    searchApplications();
    renderReports();

    showMessage("productMessage", "Данные товара изменены.");
}

function deleteProduct(id) {
    if (applications.some(item => item.productId === id)) {
        alert("Нельзя удалить товар, который используется в заявках.");
        return;
    }

    if (!confirm("Удалить товар?")) return;

    products = products.filter(item => item.id !== id);

    saveData();
    renderProducts();
    renderProductSelect();
}

/* СОТРУДНИКИ */

function renderEmployeeSelect() {
    const select = document.getElementById("employee");
    if (!select) return;

    select.innerHTML = '<option value="">Выберите сотрудника</option>';

    employees.forEach(employee => {
        const option = document.createElement("option");
        option.value = employee.id;
        option.textContent = employee.name + " — " + employee.position;
        select.appendChild(option);
    });
}

function addEmployee() {
    const name = document.getElementById("newEmployeeName").value.trim();
    const position = document.getElementById("newEmployeePosition").value.trim();

    if (name.length < 2 || name.length > 100 || /[<>]/.test(name)) {
        showMessage("employeeMessage", "Введите ФИО длиной от 2 до 100 символов.", false);
        return;
    }

    if (position.length < 2 || position.length > 80 || /[<>]/.test(position)) {
        showMessage("employeeMessage", "Введите должность длиной от 2 до 80 символов.", false);
        return;
    }

    employees.push({
        id: nextId(employees),
        name,
        position
    });

    saveData();
    renderEmployees();
    renderEmployeeSelect();

    document.getElementById("newEmployeeName").value = "";
    document.getElementById("newEmployeePosition").value = "";

    showMessage("employeeMessage", "Сотрудник успешно добавлен.");
}

function renderEmployees() {
    const table = document.getElementById("employeesTable");
    table.innerHTML = "";

    employees.forEach((employee, index) => {
        const row = document.createElement("tr");

        row.innerHTML = `
            <td>${index + 1}</td>
            <td>${escapeHTML(employee.name)}</td>
            <td>${escapeHTML(employee.position)}</td>
            <td>
                <button class="action-button edit"
                    onclick="editEmployee(${employee.id})">Изменить</button>
                <button class="action-button danger"
                    onclick="deleteEmployee(${employee.id})">Удалить</button>
            </td>
        `;

        table.appendChild(row);
    });
}

function editEmployee(id) {
    const employee = getEmployee(id);
    if (!employee) return;

    const name = prompt("Введите новое ФИО сотрудника:", employee.name);
    if (name === null) return;

    const position = prompt("Введите новую должность:", employee.position);
    if (position === null) return;

    const cleanName = name.trim();
    const cleanPosition = position.trim();

    if (cleanName.length < 2 || cleanName.length > 100 || /[<>]/.test(cleanName)) {
        alert("Введите корректное ФИО.");
        return;
    }

    if (cleanPosition.length < 2 || cleanPosition.length > 80 || /[<>]/.test(cleanPosition)) {
        alert("Введите корректную должность.");
        return;
    }

    employee.name = cleanName;
    employee.position = cleanPosition;

    saveData();
    renderEmployees();
    renderEmployeeSelect();
    renderApplications();
    searchApplications();
    renderReports();

    showMessage("employeeMessage", "Данные сотрудника изменены.");
}

function deleteEmployee(id) {
    if (applications.some(item => item.employeeId === id)) {
        alert("Нельзя удалить сотрудника, который указан в существующих заявках.");
        return;
    }

    if (!confirm("Удалить сотрудника?")) return;

    employees = employees.filter(item => item.id !== id);

    saveData();
    renderEmployees();
    renderEmployeeSelect();
}

/* ЗАЯВКИ */

function updateApplicationPrice() {
    const productId = Number(document.getElementById("product").value);
    const quantity = Number(document.getElementById("quantity").value);

    const product = getProduct(productId);
    const price = product && Number.isInteger(quantity) && quantity > 0
        ? product.price * quantity
        : 0;

    document.getElementById("applicationPrice").textContent = formatPrice(price);
}

function addApplication() {
    const customerId = Number(document.getElementById("customer").value);
    const employeeId = Number(document.getElementById("employee").value);
    const productId = Number(document.getElementById("product").value);
    const quantityText = document.getElementById("quantity").value.trim();
    const quantity = Number(quantityText);
    const status = document.getElementById("status").value;

    if (!getCustomer(customerId)) {
        showMessage("message", "Выберите покупателя.", false);
        return;
    }

    if (!getEmployee(employeeId)) {
        showMessage("message", "Выберите сотрудника.", false);
        return;
    }

    if (!getProduct(productId)) {
        showMessage("message", "Выберите товар.", false);
        return;
    }

    if (
        quantityText === "" ||
        !Number.isInteger(quantity) ||
        quantity < 1 ||
        quantity > 100
    ) {
        showMessage("message", "Количество должно быть целым числом от 1 до 100.", false);
        return;
    }

    if (!statuses.includes(status)) {
        showMessage("message", "Выбран недопустимый статус заявки.", false);
        return;
    }

    const newApplication = {
        id: nextId(applications),
        customerId,
        employeeId,
        productId,
        quantity,
        date: getCurrentDate(),
        status
    };

    applications.push(newApplication);

    saveData();
    renderApplications();
    searchApplications();
    renderReports();
    updateStatistics();

    document.getElementById("product").value = "";
    document.getElementById("quantity").value = "";

    updateApplicationPrice();

    showMessage(
        "message",
        "Заявка №" + String(newApplication.id).padStart(3, "0") + " успешно добавлена!"
    );
}

function renderApplications() {
    const table = document.getElementById("applicationTable");
    if (!table) return;

    table.innerHTML = "";

    const filter = (document.getElementById("applicationFilter")?.value || "")
        .trim().toLowerCase();

    const sort = document.getElementById("applicationSort")?.value || "id";

    let list = applications.filter(application => {
        const customer = getCustomer(application.customerId);
        const product = getProduct(application.productId);
        const employee = getEmployee(application.employeeId);

        const text = [
            application.id,
            application.date,
            application.status,
            customer?.name,
            customer?.phone,
            product?.name,
            employee?.name
        ].join(" ").toLowerCase();

        return text.includes(filter);
    });

    list.sort((a, b) => {
        if (sort === "date") return parseDate(b.date) - parseDate(a.date);
        if (sort === "price") return getApplicationPrice(b) - getApplicationPrice(a);
        if (sort === "status") return a.status.localeCompare(b.status, "ru");
        return a.id - b.id;
    });

    list.forEach(application => {
        const customer = getCustomer(application.customerId);
        const product = getProduct(application.productId);
        const employee = getEmployee(application.employeeId);

        const row = document.createElement("tr");

        row.innerHTML = `
            <td>${String(application.id).padStart(3, "0")}</td>
            <td>${escapeHTML(customer?.name || "—")}</td>
            <td>${escapeHTML(customer?.phone || "—")}</td>
            <td>${escapeHTML(product?.name || "—")}</td>
            <td>${application.quantity}</td>
            <td>${escapeHTML(employee?.name || "—")}</td>
            <td>${escapeHTML(application.date)}</td>
            <td>
                <span class="status ${getStatusClass(application.status)}">
                    ${escapeHTML(application.status)}
                </span>
            </td>
            <td>${formatPrice(getApplicationPrice(application))}</td>
            <td>
                <button class="action-button"
                    onclick="showApplicationDetails(${application.id})">Подробнее</button>
                <button class="action-button edit"
                    onclick="editApplicationStatus(${application.id})">Статус</button>
                <button class="action-button danger"
                    onclick="deleteApplication(${application.id})">Удалить</button>
            </td>
        `;

        table.appendChild(row);
    });

    document.getElementById("applicationsEmpty").textContent =
        list.length ? "" : "Заявки не найдены.";
}

function editApplicationStatus(id) {
    const application = applications.find(item => item.id === id);
    if (!application) return;

    const answer = prompt(
        "Выберите статус:\n1 — Новая\n2 — В обработке\n3 — Выполнена",
        String(statuses.indexOf(application.status) + 1)
    );

    if (answer === null) return;

    const index = Number(answer);

    if (!Number.isInteger(index) || index < 1 || index > statuses.length) {
        alert("Введите 1, 2 или 3.");
        return;
    }

    application.status = statuses[index - 1];

    saveData();
    renderApplications();
    searchApplications();
    renderReports();
    updateStatistics();

    if (currentDetailsId === id) renderApplicationDetails(id);
}

function deleteApplication(id) {
    if (!confirm("Удалить заявку №" + id + "?")) return;

    applications = applications.filter(item => item.id !== id);

    saveData();
    renderApplications();
    searchApplications();
    renderReports();
    updateStatistics();

    if (currentDetailsId === id) {
        currentDetailsId = null;
        openPage("applications");
    }
}

let currentDetailsId = null;

function showApplicationDetails(id) {
    currentDetailsId = id;
    openPage("details");
}

function renderApplicationDetails(id) {
    const application = applications.find(item => item.id === id);
    const container = document.getElementById("applicationDetails");

    if (!application) {
        container.textContent = "Заявка не найдена.";
        return;
    }

    const customer = getCustomer(application.customerId);
    const product = getProduct(application.productId);
    const employee = getEmployee(application.employeeId);

    container.innerHTML = `
        <div class="detail-line">
            <strong>Номер заявки:</strong> ${String(application.id).padStart(3, "0")}
        </div>
        <div class="detail-line">
            <strong>Покупатель:</strong> ${escapeHTML(customer?.name || "—")}
        </div>
        <div class="detail-line">
            <strong>Телефон:</strong> ${escapeHTML(customer?.phone || "—")}
        </div>
        <div class="detail-line">
            <strong>Товар:</strong> ${escapeHTML(product?.name || "—")}
        </div>
        <div class="detail-line">
            <strong>Цена за единицу:</strong> ${formatPrice(product?.price || 0)}
        </div>
        <div class="detail-line">
            <strong>Количество:</strong> ${application.quantity}
        </div>
        <div class="detail-line">
            <strong>Общая стоимость:</strong> ${formatPrice(getApplicationPrice(application))}
        </div>
        <div class="detail-line">
            <strong>Сотрудник:</strong> ${escapeHTML(employee?.name || "—")}
        </div>
        <div class="detail-line">
            <strong>Должность:</strong> ${escapeHTML(employee?.position || "—")}
        </div>
        <div class="detail-line">
            <strong>Дата:</strong> ${escapeHTML(application.date)}
        </div>
        <div class="detail-line">
            <strong>Статус:</strong> ${escapeHTML(application.status)}
        </div>
        <button class="primary" style="margin-top:20px"
            onclick="editApplicationStatus(${application.id})">Изменить статус</button>
    `;
}

/* ПОИСК */

function searchApplications() {
    const input = document.getElementById("searchInput");
    const table = document.getElementById("searchTable");

    if (!input || !table) return;

    const query = input.value.trim().toLowerCase();
    table.innerHTML = "";

    let count = 0;

    applications.forEach(application => {
        const customer = getCustomer(application.customerId);
        const product = getProduct(application.productId);
        const employee = getEmployee(application.employeeId);

        const text = [
            application.id,
            customer?.name,
            customer?.phone,
            product?.name,
            employee?.name,
            application.date,
            application.status,
            getApplicationPrice(application)
        ].join(" ").toLowerCase();

        if (!text.includes(query)) return;

        count++;

        const row = document.createElement("tr");

        row.innerHTML = `
            <td>${String(application.id).padStart(3, "0")}</td>
            <td>${escapeHTML(customer?.name || "—")}</td>
            <td>${escapeHTML(customer?.phone || "—")}</td>
            <td>${escapeHTML(product?.name || "—")}</td>
            <td>${escapeHTML(employee?.name || "—")}</td>
            <td>${escapeHTML(application.date)}</td>
            <td>
                <span class="status ${getStatusClass(application.status)}">
                    ${escapeHTML(application.status)}
                </span>
            </td>
            <td>${formatPrice(getApplicationPrice(application))}</td>
            <td>
                <button class="action-button"
                    onclick="showApplicationDetails(${application.id})">Подробнее</button>
                <button class="action-button edit"
                    onclick="editApplicationStatus(${application.id})">Статус</button>
            </td>
        `;

        table.appendChild(row);
    });

    document.getElementById("searchEmpty").textContent =
        count ? "" : "По вашему запросу ничего не найдено.";
}

/* СТАТИСТИКА И ОТЧЁТЫ */

function updateStatistics() {
    const total = applications.length;
    const newCount = applications.filter(item => item.status === "Новая").length;
    const doneCount = applications.filter(item => item.status === "Выполнена").length;
    const processCount = applications.filter(item => item.status === "В обработке").length;

    document.getElementById("totalApplications").textContent = total;
    document.getElementById("newApplications").textContent = newCount;
    document.getElementById("doneApplications").textContent = doneCount;
    document.getElementById("customersCount").textContent = customers.length;

    document.getElementById("reportTotal").textContent = total;
    document.getElementById("reportNew").textContent = newCount;
    document.getElementById("reportDone").textContent = doneCount;
    document.getElementById("reportProcess").textContent = processCount;
}

function renderReports() {
    updateStatistics();

    const totalValue = applications.reduce(
        (sum, application) => sum + getApplicationPrice(application), 0
    );

    const totalQuantity = applications.reduce(
        (sum, application) => sum + application.quantity, 0
    );

    document.getElementById("reportRevenue").textContent = formatPrice(totalValue);

    document.getElementById("reportAverage").textContent = formatPrice(
        applications.length ? totalValue / applications.length : 0
    );

    document.getElementById("reportQuantity").textContent = totalQuantity;

    const table = document.getElementById("reportTable");
    table.innerHTML = "";

    applications.forEach(application => {
        const customer = getCustomer(application.customerId);
        const product = getProduct(application.productId);
        const employee = getEmployee(application.employeeId);

        const row = document.createElement("tr");

        row.innerHTML = `
            <td>${String(application.id).padStart(3, "0")}</td>
            <td>${escapeHTML(customer?.name || "—")}</td>
            <td>${escapeHTML(product?.name || "—")}</td>
            <td>${application.quantity}</td>
            <td>${escapeHTML(employee?.name || "—")}</td>
            <td>${escapeHTML(application.date)}</td>
            <td>${escapeHTML(application.status)}</td>
            <td>${formatPrice(getApplicationPrice(application))}</td>
        `;

        table.appendChild(row);
    });
}

function exportReport() {
    const rows = [
        [
            "Номер заявки",
            "Покупатель",
            "Телефон",
            "Товар",
            "Количество",
            "Сотрудник",
            "Дата",
            "Статус",
            "Стоимость"
        ]
    ];

    applications.forEach(application => {
        const customer = getCustomer(application.customerId);
        const product = getProduct(application.productId);
        const employee = getEmployee(application.employeeId);

        rows.push([
            application.id,
            customer?.name || "",
            customer?.phone || "",
            product?.name || "",
            application.quantity,
            employee?.name || "",
            application.date,
            application.status,
            getApplicationPrice(application)
        ]);
    });

    function csvCell(value) {
        return '"' + String(value).replace(/"/g, '""') + '"';
    }

    const csv = "\uFEFF" + rows
        .map(row => row.map(csvCell).join(";"))
        .join("\r\n");

    const blob = new Blob([csv], {
        type: "text/csv;charset=utf-8;"
    });

    const url = URL.createObjectURL(blob);
    const link = document.createElement("a");

    link.href = url;
    link.download = "otchet_pixel.csv";

    document.body.appendChild(link);
    link.click();
    link.remove();

    URL.revokeObjectURL(url);

    showMessage("reportMessage", "Отчёт подготовлен для скачивания.");
}

/* ПЕРЕСЧЁТ СТОИМОСТИ */

document.getElementById("product").addEventListener("change", updateApplicationPrice);
document.getElementById("quantity").addEventListener("input", updateApplicationPrice);

/* ЗАПУСК СИСТЕМЫ */

loadData();

renderCustomerSelect();
renderProductSelect();
renderEmployeeSelect();

renderApplications();
renderCustomers();
renderProducts();
renderEmployees();
searchApplications();
renderReports();
updateStatistics();
updateApplicationPrice();



const loginForm = document.getElementById("loginForm");
const loginScreen = document.getElementById("loginScreen");
const loginMessage = document.getElementById("loginMessage");

const accounts = {
    admin: {
        username: "admin",
        password: "admin123",
        role: "admin"
    },
    employee: {
        username: "employee",
        password: "employee123",
        role: "employee"
    }
};

const employeePages = [
    "home",
    "applications",
    "add",
    "customers",
    "products",
    "search"
];

let currentRole = null;

// Сохраняем существующую навигацию сайта
const originalShowPage = window.showPage;

window.showPage = function(page) {
    if (!currentRole) return;

    if (currentRole === "employee" &&
        !employeePages.includes(page)) {
        alert("У вас нет доступа к этому разделу.");
        return;
    }

    if (typeof originalShowPage === "function") {
        originalShowPage(page);
    }
};

// Вход в систему
loginForm.addEventListener("submit", function(event) {
    event.preventDefault();

    const selectedRole =
        document.getElementById("loginRole").value;
    const username =
        document.getElementById("loginUsername").value.trim();
    const password =
        document.getElementById("loginPassword").value;

    const account = accounts[selectedRole];

    if (
        username !== account.username ||
        password !== account.password
    ) {
        loginMessage.textContent =
            "Неверный логин или пароль.";
        return;
    }

    currentRole = account.role;

    loginScreen.style.display = "none";

    // Скрываем недоступные пункты меню сотрудника
    document.querySelectorAll("[onclick]").forEach(function(element) {
        const action = element.getAttribute("onclick") || "";

        const pages = action.match(
            /showPage\(['"]([^'"]+)['"]\)/g
        );

        if (!pages) return;

        const pageMatch = action.match(
            /showPage\(['"]([^'"]+)['"]\)/
        );

        if (!pageMatch) return;

        const page = pageMatch[1];

        if (currentRole === "employee") {
            element.style.display =
                employeePages.includes(page) ? "" : "none";
        } else {
            element.style.display = "";
        }
    });

    // Скрываем сами разделы, если они недоступны сотруднику
    const employeesSection = document.getElementById("employees");
    const reportsSection = document.getElementById("reports");

    if (currentRole === "employee") {
        if (employeesSection) employeesSection.style.display = "none";
        if (reportsSection) reportsSection.style.display = "none";
    }

    // Добавляем кнопку выхода
    if (!document.getElementById("logoutButton")) {
        const logoutButton = document.createElement("button");
        logoutButton.id = "logoutButton";
        logoutButton.textContent = "Выйти";
        logoutButton.onclick = function() {
            currentRole = null;
            location.reload();
        };

        document.querySelector("header")?.appendChild(logoutButton);
    }

    window.showPage("home");
});

// Не разрешаем пользоваться сайтом до входа
document.addEventListener("DOMContentLoaded", function() {
    loginScreen.style.display = "flex";
});
